from datetime import date

from django.test import TestCase
from django.urls import reverse

from .models import Booking


class BookingTests(TestCase):
    def test_booking_form_renders_date_picker_and_slots(self):
        response = self.client.get(reverse('booking-form'))

        self.assertEqual(response.status_code, 200)
        self.assertContains(response, 'type="date"')
        self.assertContains(response, 'name="reservation_slot"')

    def test_list_bookings_and_filter_by_date(self):
        Booking.objects.create(
            first_name='Ari', reservation_date=date(2026, 10, 7), reservation_slot='10:00'
        )

        response = self.client.get('/bookings')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()), 1)

        response = self.client.get('/bookings', {'date': '2026-10-07'})
        self.assertEqual(response.json()[0]['first_name'], 'Ari')

        response = self.client.get('/bookings', {'date': '2026-10-08'})
        self.assertEqual(response.json(), {'message': 'No Booking'})

    def test_duplicate_slot_is_rejected(self):
        payload = {
            'first_name': 'Ari',
            'reservation_date': '2026-10-07',
            'reservation_slot': '10:00',
        }
        first_response = self.client.post('/bookings', payload)
        second_response = self.client.post('/bookings', payload)

        self.assertEqual(first_response.status_code, 201)
        self.assertEqual(second_response.status_code, 409)
        self.assertEqual(Booking.objects.count(), 1)
